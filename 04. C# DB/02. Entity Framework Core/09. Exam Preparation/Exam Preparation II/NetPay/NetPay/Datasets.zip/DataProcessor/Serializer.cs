﻿using NetPay.Data;

namespace NetPay.DataProcessor
{
    public class Serializer
    {
        public static string ExportHouseholdsWhichHaveExpensesToPay(NetPayContext context)
        {
            return null;
        }

        public static string ExportAllServicesWithSuppliers(NetPayContext context)
        {
            return null;
        }
    }
}
